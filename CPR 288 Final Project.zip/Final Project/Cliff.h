/*
 * Cliff.h
 *
 *  Created on: Apr 14, 2022
 *      Author: abashara
 */

#ifndef CLIFF_H_
#define CLIFF_H_

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <inc/tm4c123gh6pm.h>
#include "Timer.h"

void cliffData(oi_t *sensor_data);



#endif /* CLIFF_H_ */
